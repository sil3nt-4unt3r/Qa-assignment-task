# QATestTask
```javascript
Develop and Design detailed test cases 
Write the required automation testing scripts to automate the testing flow 
Document all steps and outcomes of your testing 
