package com.eyecan.app.models

data class SignInRequest(
    val emailId: String, val password: String
)
